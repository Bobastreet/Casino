--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

--[[
	This is the normal way mCasino is opened, you can abstract from it whatever you like!
	The main parts are:
    - mCasino.mainFrame should always be the active mCasino frame the user is using
    - There should only ever be one mCasino.mainFrame at a time (check at line 20)
--]]

function mCasino_devKit.open()
	if not IsValid(LocalPlayer()) then return end -- Check if LocalPlayer is valid
	if not LocalPlayer():isCasinoLoaded() then return end -- Check if casino is loaded

	if IsValid(mCasino.mainFrame) then -- Only have one active casino at a time
		mCasino.alert(mCasino.getLang("casino_open"), mCasino.getLang("casino_open_msg"))
		return 
	end

	local w,h = ScrW(),ScrH()
	mCasino.mainFrame = vgui.Create("mCasino_devKit_frame")
	mCasino.mainFrame:SetSize(w*0.9,h*0.8)
	mCasino.mainFrame:Center()
	mCasino.mainFrame:MakePopup()
end

net.Receive("mCasino_devKit_open", function()
	mCasino_devKit.open()
end)