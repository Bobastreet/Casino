--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

util.AddNetworkString("mCasino_devKit_open")

// Open mCasino
function mCasino_devKit.open(ply)
    if not mCasino then return end -- Check for mCasino
	if not IsValid(ply) then return end -- Detect invalid users
	if not mCasino.isOnlineAlert(ply) then -- This checks if mCasino is online
        ply:ChatPrint("mCasino is not ready yet, please try again")
        return 
    end

	if(IsValid(mCasino.api.player.getKiosk(ply)))then
		mCasino.notify(ply,1,0,mCasino.getLang("casino_open"), mCasino.getLang("casino_open_msg"))
		return 
	end

	mCasino.api.player.updateGems(ply,function()
		if(ply:isCasinoLoadedAlert())then -- Checks if casino is loaded from the update gems function
			net.Start("mCasino_devKit_open")
			net.Send(ply)
		end
	end)
end

concommand.Add("mcasino_devkit", function(ply)
    mCasino_devKit.open(ply)
end)