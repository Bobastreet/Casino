--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2021 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

include("shared.lua")

function ENT:Initialize()
	if(not mCasino) then return end
	mCasino.kiosk.entity.init(self)
end

function ENT:Draw()
	if(not mCasino or not self.clientInit) then self:DrawModel() return end
	mCasino.kiosk.entity.draw(self)
end

function ENT:OnRemove()
	if(not mCasino) then return end
	mCasino.kiosk.entity.onRemove(self)
end

function ENT:OnWin()
	if(not mCasino) then return end
	mCasino.kiosk.entity.onWin(self)
end