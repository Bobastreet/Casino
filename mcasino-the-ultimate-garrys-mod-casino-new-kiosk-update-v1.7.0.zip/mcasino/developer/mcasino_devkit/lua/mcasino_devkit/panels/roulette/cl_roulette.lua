--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// The content base is just a DPanel with a scroll view and header title + help + mute toggle
// You can either create your own or just edit the paint function if you want to change colors
DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("roulette"))
	self:SetHelpText(mCasino.getLang("roulette_help"))
	
	// Mute
	self:AddMute()
	
	// History
	self.history = self.scroll:Add("mCasino_button")
	self.history:SetIcon("mcasino/history.png")
	self.history.DoClick = function()
		mCasino.api.history.show("roulette")
	end
	
	// Main Roulette Panel - This is the wheel that spins
	self.roulette = self.scroll:Add("mCasino_roulettePanel")
	
	// Bet Amount Panel - This allows the user to set their bet amount
	self.bet = self.scroll:Add("mCasino_rouletteBet")
	
	local getBet = function() return self.bet:GetBet() end

	// Player and submit panels, internally uses mCasino.api.roulette.bet(amount, color) to submit bets
	self.redSubmit = self.scroll:Add("mCasino_rouletteSubmit")
	self.redSubmit:SetColor(1)
	self.redSubmit.GetBet = getBet

	self.blackSubmit = self.scroll:Add("mCasino_rouletteSubmit")
	self.blackSubmit:SetColor(2)
	self.blackSubmit.GetBet = getBet

	self.greenSubmit = self.scroll:Add("mCasino_rouletteSubmit")
	self.greenSubmit:SetColor(3)
	self.greenSubmit.GetBet = getBet
	
	// Hide bet panel when not the current user
	if(mCasino.getRootPanel(self):IsOtherUser())then
		self.bet:SetVisible(false)
	end

	// Register panel for updates
    mCasino.setPanel(self, "roulette")
end

function PANEL:OnRemove()
	// Unregister panel
    mCasino.setPanel(self, nil)
end

function PANEL:SendUpdate()
    if(next(mCasino.roulette.game.players))then
        // Internally uses mCasino.api.roulette.getPlayers(), .getStates(), .getState()
        local count = mCasino.api.roulette.calculatePlayers(
            function(ply, sid, color, amount)
				if(color == 1)then
					self.redSubmit:AddPlayer(ply,sid,amount)
				elseif(color == 2)then
					self.blackSubmit:AddPlayer(ply,sid,amount)
				elseif(color == 3)then
					self.greenSubmit:AddPlayer(ply,sid,amount)
				end
            end,
            function()
                // If an entity is related, pass on the win
                if(IsValid(self:GetEntity()))then
                    self:GetEntity():OnWin()
                end
            end
        )

        self.redSubmit:SetHeaderGems(count[1])
		self.blackSubmit:SetHeaderGems(count[2])
		self.greenSubmit:SetHeaderGems(count[3])
		
		self.redSubmit:DoSorting()
		self.blackSubmit:DoSorting()
		self.greenSubmit:DoSorting()
    else
		self.redSubmit:Clear()
		self.blackSubmit:Clear()
		self.greenSubmit:Clear()
    end

	if(mCasino.api.roulette.getState() == mCasino.api.roulette.getStates()["SPINNING"])then
		self.roulette:SpinToValue()
	end
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	
	self.mute:SetSize(h*0.05,h*0.05)
	self.mute:SetPos(select(1,self.help:GetPos()) - self.mute:GetWide() - 4,h*0.025)
	
	self.history:SetSize(h*0.05,h*0.05)
	self.history:SetPos(select(1,self.mute:GetPos()) - self.history:GetWide() - 4,h*0.025)
	
	self.yPos = self.yPos + self.ySpacing
	self.roulette:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.roulette:SetSize(w*self.pM,h*0.15)
	self.yPos = self.yPos + h*0.15
	
	self.yPos = self.yPos + self.ySpacing
	self.bet:SetPos(w*0.5 - w*self.pM*0.5, self.yPos)
	self.bet:SetSize(w*self.pM,h*0.1)
	self.yPos = self.yPos + h*0.1
	
	self.yPos = self.yPos + self.ySpacing
	local pnlWidth = ((w*self.pM) - w*0.05)/3
	
	self.redSubmit:SetPos(w*0.5 - w*self.pM*0.5, self.yPos)
	self.redSubmit:SetWide(pnlWidth)
	
	self.greenSubmit:SetPos(w*0.525 - w*self.pM*0.5 + pnlWidth, self.yPos)
	self.greenSubmit:SetWide(pnlWidth)
	
	self.blackSubmit:SetPos(w*0.55 - w*self.pM*0.5 + pnlWidth*2, self.yPos)
	self.blackSubmit:SetWide(pnlWidth)
	
end
vgui.Register( "mCasino_devKit_roulette", PANEL, "mCasino_contentBase" )