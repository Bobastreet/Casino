--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// This is a helper function to run code after mCasino is loaded
function mCasino_devKit.onFinishLoad(callback)
    if(mCasino)then
        callback()
    else
        // Quick and dirty way to get an ID for the hook
        local id = os.time() + math.Rand(1000, 9000)
        local key = "mCasino_devKit_onFinishLoad_" .. id
        hook.Add("mCasino_loaded", key, function()
            hook.Remove("mCasino_loaded", key)
            callback()
        end)
    end
end