--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2021 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// FILE VERSION: 2 - View lastest versions here: https://docs.m4dsolutions.com/#/category/1/article/4
mCasino.config.fileVersions = mCasino.config.fileVersions or {}
mCasino.config.fileVersions["config/cl_config.lua"] = 2

// Documentation: https://docs.m4dsolutions.com/#/category/1/article/2

mCasino.config.colors = {}

// Main
mCasino.config.colors.bg = Color(60,68,82) // Background Color
mCasino.config.colors.head = Color(76,86,103) // Header Color
mCasino.config.colors.hover = Color(68,77,92) // Hovered Button Color
mCasino.config.colors.accent = Color(0,194,146) // Accent Color
mCasino.config.colors.sidebar = Color(53,60,72) // Sidebar Color
mCasino.config.colors.border = Color(76,85,98) // Border Color
mCasino.config.colors.panel = Color(53,60,72) // Panel Color
mCasino.config.colors.uiBorder = Color(120,130,140,51) // UI Border
mCasino.config.colors.tableAlternate = Color(0,0,0,26) // Alternate Table Line Color
mCasino.config.colors.tablePlayer = Color(63,70,82) // Current Player Table Line Color
mCasino.config.colors.scrollGrip = Color(190,190,190,102) // Scroll Grip Color

// Roulette
mCasino.config.colors.rRed = Color(180,43,45) // Red Roulette Number
mCasino.config.colors.rBlack = Color(32,32,37) // Black Roulette Number
mCasino.config.colors.rGreen = Color(8,151,79) // Green Roulette Number
mCasino.config.colors.rFont = Color(255,255,255) // Roulette Number Font Color
mCasino.config.colors.rCenter = Color(251,150,120) // Roulette Center Line Color

// Crash
mCasino.config.colors.cLine = Color(7,171,84) // Crash Line Color
mCasino.config.colors.cText = Color(255,0,0) // Crashed Text Color
mCasino.config.colors.cGreen = Color(64,134,9) // Crash Green
mCasino.config.colors.cRed = Color(224,62,62) // Crash Red
mCasino.config.colors.cOrange = Color(255,129,0) // Crash Orange

// Coinflip
mCasino.config.colors.cfRed = Color(214, 69, 65) // Red Coin
mCasino.config.colors.cfBlue = Color(52, 152, 219) // Blue Coin

// Admin
mCasino.config.colors.aRed = Color(180,43,45) // Red
mCasino.config.colors.aGreen = Color(8,151,79) // Green
mCasino.config.colors.aOrange = Color(245, 171, 53) // Orange