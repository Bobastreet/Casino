--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright � 2017 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// FILE VERSION: 1 - View lastest versions here: https://docs.m4dsolutions.com/#/category/1/article/4
mCasino.config.fileVersions = mCasino.config.fileVersions or {}
mCasino.config.fileVersions["config/sh_config.lua"] = 1

// Documentation: https://docs.m4dsolutions.com/#/category/1/article/2

// Permissions
mCasino.config.gamePermissions = {
	roulette = { // Who can play Roulette, if no ranks specified, everyone is allowed to play
		// "vip"
	},
	crash = { // Who can play Crash, if no ranks specified, everyone is allowed to play
		// "vip"
	}
}
mCasino.config.canEdit = {"superadmin"} // People allowed to edit mCasino settings
mCasino.config.canManageGems = {"superadmin"} // People allowed to give/take gems to people

// Withdraw Items
// Current types are: "weapon"
mCasino.config.withdrawItems = {
	//{name = ".357", type = "weapon", class="weapon_357", model="models/weapons/w_357.mdl", cost=500},
	//{name = "AR2", type = "weapon", class="weapon_ar2", model="models/weapons/w_irifle.mdl", cost=400},
}
	