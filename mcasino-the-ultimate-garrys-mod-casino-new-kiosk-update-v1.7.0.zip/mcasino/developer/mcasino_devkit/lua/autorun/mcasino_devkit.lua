--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

mCasino_devKit = mCasino_devKit or {}
mCasino_devKit.version = "1.0.0"

local root = "mcasino_devkit/"

local folderOrder = {
	"core",
	"panels"
}

if SERVER then
	function mCasino_devKit.serverLoad(path)
		for _, Fol in pairs(select(2,file.Find(path .."/*", "LUA"))) do
			mCasino_devKit.serverLoad(path.. "/" ..Fol)
		end
		
		for _, File in SortedPairs(file.Find(path .."/sh_*.lua", "LUA"), true) do
			AddCSLuaFile(path .. "/" ..File)
			include(path .. "/" ..File)
		end
		
		for _, File in SortedPairs(file.Find(path .."/sv_*.lua", "LUA"), true) do
			include(path .. "/" ..File)
		end

		for _, File in SortedPairs(file.Find(path .."/cl_*.lua", "LUA"), true) do
			AddCSLuaFile(path .. "/" ..File)
		end
	end
	
    
	for _, folder in pairs(folderOrder) do
		mCasino_devKit.serverLoad(root .. folder)
	end
else
	function mCasino_devKit.clientLoad(path)
		for _, File in SortedPairs(file.Find(path .."/sh_*.lua", "LUA"), true) do
			include(path .. "/" ..File)
		end
		for _, Fol in pairs(select(2,file.Find(path .."/*", "LUA"))) do
			mCasino_devKit.clientLoad(path.. "/" ..Fol)
		end
		for _, File in SortedPairs(file.Find(path .."/cl_*.lua", "LUA"), true) do
			include(path .. "/" ..File)
		end
	end

	for _, folder in pairs(folderOrder) do
		mCasino_devKit.clientLoad(root .. folder)
	end
end