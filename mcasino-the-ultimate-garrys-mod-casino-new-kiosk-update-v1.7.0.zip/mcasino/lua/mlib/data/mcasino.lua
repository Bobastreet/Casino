mLib.Addons["mcasino"] = {
	name = "mCasino",
	key = "mcasino",
	uid = "76561198884236357",
	hid = "11cc29510f99c6ce804501c26ab737f020939b4fe2f189c261a80e41f2724f6d"
}