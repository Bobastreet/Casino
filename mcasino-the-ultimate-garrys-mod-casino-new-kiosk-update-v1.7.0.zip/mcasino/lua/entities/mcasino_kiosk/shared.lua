--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2021 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Kiosk"
ENT.Author = "M4D Solutions"
ENT.Contact = "Madhead (https://www.gmodstore.com/users/M4dhead)"
ENT.Spawnable = true
ENT.Category = "mCasino"
ENT.AdminSpawnable = true 

ENT.ScreenPos = Vector(-6, -15.8, 64.5)
ENT.ScreenAng = Angle(0,90,65.5)
ENT.ScreenWorldSize = Vector(31.5,7.48)
ENT.ScreenSize = Vector(2048, 1170)
ENT.MenuButtonPos = Vector(6,0,45)
ENT.MainScreenIdx = 1
ENT.BannerScreenIdx = 2
ENT.ParticleSpawnPoint = Vector(0,0,80)

function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "State" )
	self:NetworkVar( "Entity", 0, "Player" )
	
	if(CLIENT)then
		self:NetworkVarNotify("State", function(self, _, old, new)
			if(not mCasino) then return end
			mCasino.kiosk.entity.varChanges["State"](self, old, new)
		end)
	end
 end