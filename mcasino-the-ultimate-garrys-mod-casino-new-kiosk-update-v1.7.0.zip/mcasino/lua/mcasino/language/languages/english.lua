--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2021 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// FILE VERSION: 1.12 - View lastest versions here: https://docs.m4dsolutions.com/#/category/1/article/4
mCasino.config.fileVersions = mCasino.config.fileVersions or {}
mCasino.config.fileVersions["language/languages/english.lua"] = "1.12"

// Documentation: https://docs.m4dsolutions.com/#/category/1/article/2

// The english translation of mCasino, this file will be updated so visit https://docs.m4dsolutions.com/#/category/1/article/4 for the lastest version.
// If you want to create your own language create a file in this directory and follow the same schema as this file.
local lang = {
	// General
	error = "Error",

	// Config
	invalid_config = "Error! The config is invalid!",
	loaded_config = "Loaded Config Successfully!",

	// Developer Mode
	developer_mode_enabled = "Developer Mode Active",
	game_cancelled_developer_mode = "This game has been cancelled due to developer mode being enabled, you have not been charged!",

	// Core
	casino_not_loaded = "%s has tried to use mCasino before being loaded, if this problem occurs often check your storage settings! e.g. MySQL not being able to connect",
	not_validated = "Not validated",
	not_validated_msg = "Sorry, you have not been validated to use mCasino yet, please try again later!",
	no_storage_connection = "%s has tried to use mCasino however we do not have a storage connection! Please check your provider settings!",
	not_online = "Not online",
	not_online_msg = "Sorry, mCasino is not online at the moment! Please try again later!",

	// Networking
	please_wait_before_trying = "Please wait before trying this again!",

	// General Game
	invalid_amount = "Invalid Amount",
	enter_valid_amount = "Please enter a valid amount!",
	bet_too_high = "The maximum bet is %i gems",
	bet_amount = "Bet Amount",
	insufficient_balance = "Insufficient Balance",
	not_enough_gems_for_bet = "You do not have enough gems to place this bet!",
	player = "Player",
	bet = "Bet",
	profit = "Profit",
	no_current_bets = "No current bets",
	max = "Max",
	multiplier_x = "%sx",
	waiting_for_players = "Waiting for players",
	new_game_in_x = "New game in: %is",
	are_you_sure = "Are you sure?",

	// Crash
	crash = "Crash",
	crash_help =
	[[Place a bet. Watch the multiplier increase from 1x upwards! Cash out any time to get your bet multiplied by that multiplier.

	But be careful because the game can crash at any time, and you'll get nothing! ]],
	cannot_remove_bet = "You cannot remove your bet!",
	you_won = "You won!",
	you_have_won_x = "You have won %i gems!",
	invalid_cashout = "Invalid Cashout",
	enter_valid_cashout = "Please enter a valid cashout!",
	auto_cashout = "Auto Cashout",
	betting = "Betting...",
	betting_cancel = "Betting... (Cancel)",
	cashout_at_x = "Cashout @ %i gems",
	seconds_x = "%is",
	waiting_for_information = "Waiting for game information...",
	crashed = "CRASHED",
	game_starting_in_x = "Game starting in: %is",

	// Roulette
	roulette = "Roulette",
	roulette_help =
	[[In Roulette, there is a number spinner consisting of numbers from 0 to 14, which gets selected randomly per game.

	You are able to bet on red, black and green by clicking on the colors accordingly. If the spinner lands on the color you picked you will receive the multiplier stated with the color.]],
	bets_closed = "Bets Closed",
	no_longer_place_bets = "You can no longer place bets!",
	clear = "Clear",
	spinning_in_x = "Spinning in: %is",
	unknown_player = "Unknown Player",
	roulette_round_summary = "Roulette Round Summary",
	red = "Red",
	black = "Black",
	green = "Green",

	// Exchange
	transaction_complete = "Transaction Complete",
	deposit_successful = "You have successfully deposited %s for %i gems!",
	withdraw_successful = "You have successfully withdrawn %i gems for %s!",
	withdraw_item = "You have successfully withdraw a %s for %i gems",
	withdraw_unsuccessful = "You do not have enough gems to withdraw this amount!",
	not_enough_money_for_deposit = "You do not have enough money to deposit this amount!",
	not_enough_points_for_deposit = "You do not have enough points to deposit this amount!",
	minimum_withdraw_rate = "The minimum withdraw rate is %s gems",
	mCasino_deposit = "mCasino Deposit",
	mCasino_withdraw = "mCasino Withdraw",
	exchange_rate = "Exchange Rate",
	current_balance = "Current Balance",

	// Deposit
	deposit = "Deposit",
	deposit_help =
	[[You can deposit items you already have into gems (which is the casino's currency) and will allow you to play any games in the casino.

	You can then later withdraw the gems you have played with back into items!]],
	deposit_amount = "Enter the amount of %s you want to deposit (Balance: %s)",
	are_you_sure_exchange_gems = "Are you sure want to exchange %s for %s gems?",

	// Withdraw
	withdraw = "Withdraw",
	withdraw_help =
	[[Here you can withdraw gems into different items!]],
	withdraw_amount = "Enter the amount of gems you want to withdraw (Balance: %s gems)",
	are_you_sure_exchange_x = "Are you want to exchange %s gems for %s?",
	cost = "Cost",
	item = "Item",
	item_already_equipped = "Item already equipped",
	item_already_equipped_msg = "You already have this item on you, drop it to withdraw another one!",
	are_you_sure_purchase = "Are you want to purchase a %s for %i gems?",

	// Settings
	settings = "Settings",
	settings_help =
	[[Here you can configure all of mCasino's settings!

	Provider settings (flatfile/MySQL) can be found in the mCasino/mcasino/config/sv_config.lua file.]],
	developer_mode_off = "Developer Mode: Off",
	developer_mode_on = "Developer Mode: On",
	developer_warning = "By enabling developer mode you are closing down all games from normal users! People will not be able to play until developer mode is turned off.",
	retrieving_data = "Retrieving data...",
	save = "Save",

	// Permissions
	invalid_permissions = "Invalid Permission",
	no_permission_for_action = "You do not have permission to perform this action!",
	no_access = "No Access",
	no_access_msg = "You do not have access to play this game!",


	// Gem Management
	gem_management = "Gem Management",
	gem_management_help =
	[[You can manage people's gems here by setting their balance!]],
	search = "Search:",
	page = "Page:",
	previous = "Previous",
	next = "Next",
	gem_update = "Gem Update",
	gem_update_msg = "An admin has updated your gem balance.",
	success = "Success!",
	updated_players_gems = "You have successfully updated this player's gems!",
	edit_x_gems = "Edit %s's Gems",
	enter_gems_x = "Enter the amount of gems you would like to set %s to.",
	are_you_sure_set_gems = "Are you sure you want to set %s's gems to %i?",

	// ---------- V1.1 ----------
	// Exchange
	not_enough_x_for_deposit = "You do not have enough %s to deposit this amount!",

	// ---------- V1.2 ----------
	// General
	game_disabled = "Game Disabled",
	game_disabled_msg = "This game is currently disabled by the administrator!",

	// Slots
	slots = "Slots",
	slots_help =
	[[Click spin to spin the wheel and receive a prize if the winning symbols match!]],
	spin = "Spin",
	slots_paytable = "Slots Paytable",

	// ---------- V1.3 ----------
	// Blackjack
	blackjack = "Blackjack",
	blackjack_help = 
	[[A hand's value is the sum of the card values. Players are allowed to draw additional cards to improve their hands. 
	
	Players win by not busting and having a total higher than the dealer, or not busting and having the dealer bust, or getting a blackjack without the dealer getting a blackjack.]],
	position_taken = "Position Taken",
	position_taken_msg = "This position has been taken!",
	already_playing = "Already Playing",
	already_playing_msg = "You are already playing this game!",
	no_position = "Position Not Found",
	no_position_msg = "Your position has become invalid! Rejoin to fix this issue!",
	you_have_bet_x = "You have bet %i gems",
	split = "Split",
	stand = "Stand",
	hit = "Hit",
	double_x = "Double %i Gems",
	dealer_value_x = "Dealer's Value: %i",
	round_ending = "Round Ending",
	insurance_place = "Insure bet? (%i gems)",

	// Lobby
	create_x_session = "Create %s Session",
	player_session_name = "%s's %s Session",
	session_not_found = "Session Not Found",
	session_not_found_msg = "This session is either closed or no longer valid!",
	session_full = "Session Full",
	session_full_msg = "This session is currently full!",

	// General Game
	place_bets = "Place Bets",
	dealing = "Dealing",
	x_turn = "%s's turn",
	dealer = "Dealer",
	waiting_for_next_round = "Waiting for next round",
	
	// General
	yes = "Yes",
	no = "No",
	
	// ---------- V1.4 ---------- 
	// Exchange
	money = "Money",
	points = "Points",

	// ---------- V1.5 ----------
	// General
	on = "On",
	off = "Off",

	// Lobby
	join_x = "Join %s",
	
	// Blackjack
	blackjack_round_summary = "Blackjack Round Summary",
	your_hand = "Your Hand:",
	dealers_hand = "Dealer's Hand:",
	summary = "Summary",

	// Slots
	auto_spin_x = "Auto Spin: %s",

	// ---------- V1.6 ----------
	// General
	waiting_for_player = "Waiting for player",
	gems = "Gems",
	join = "Join",
	confirm = "Confirm",

	// General Game
	invalid_bet = "Invalid Bet",
	threshold = "Your bet doesn't meet the threshold to participate in this game",
	you_won_gems_items = "You have won %i gems and %i items",
	are_you_sure_items = "Are you sure you want to bet these items? You will not be able to access the items unless cancelled.",
	no_minimum_bet = "No minimum bet",
	minimum = "Minimum",
	maximum = "Maximum",
	chance = "Chance",

	// Lobby
	session_closed = "Session Closed",
	session_closed_msg = "This session has been closed.",

	// Pointshop
	pick_items = "Pick items",
	full_inventory = "Full Inventory",
	full_inventory_msg = "You have a full inventory (%i spaces required)",
	invalid_items = "Invalid Items",
	invalid_items_msg = "Some submitted items were invalid. They may not be allowed or been removed. Please try again.",
	items_placed = "Items Placed",
	items_placed_msg = "You have items locked in this game. They cannot be returned unless you win.",
	
	// Jackpot
	jackpot = "Jackpot",
	jackpot_help = 
	[[
		A minimum of two players is required for Jackpot. Players bet gems into a pot which forms the total winning prize.

		The more players bet the more chance of winning they will have, however lower chance players will win bigger amounts.

		The spinner randomly selects a player who will then receive the pot.
	]],

	// Coinflip
	coinflip = "Coinflip",
	coinflip_help = 
	[[
		The initial player places a bet down which an opposing player will either match, or place a bet of 10%% higher or lower.

		The coin will flip and the resulting side will be the winner and win both bets.
	]],

	// ---------- V1.7 ----------

	cancel = "Cancel",

	// ---------- V1.8 ----------
	// General
	balance_full = "Balance Full",
	game_balance_full = "You cannot play any games as your balance is over the maximum limit!",
	balance_almost_full = "Your balance is almost full!",
	balance_almost_full_limit = "Your balance is almost full! You will lose any winnings over the limit.",
	maximize_casino = "Type #casino in chat to open the Casino",

	// Exchange
	deposit_balance_over_limit = "You cannot deposit any more gems as your balance is too full (Limit: %i gems)",

	// ---------- V1.9 ----------
	// Exchange
	cannot_deposit_x = "You cannot deposit %s",
	cannot_withdraw_x = "You cannot withdraw %s",

	// ---------- V1.10 ----------
	// General
	loading = "Loading",
	ok = "Ok",
	place_bet = "Place Bet",
	cashout = "Cashout",

	// Management
	name = "Name",
	edit = "Edit",
	edit_gems = "Edit Gems",
	
	// Lobby
	session_name = "Session Name",
	player_count = "Player Count",

	// ---------- V1.11 ----------
	// General
	you_lost = "You lost!",
	you_have_lost_x = "You have lost %i gems!",
	
	// ---------- V1.12 ----------
	// General
	place_bet_start = "Place a bet to start!",
	spinning = "Spinning",
	betting_x = "Betting %i gems",
	enter_bet_amount = "Enter the amount of gems you would like to bet",
	casino_open = "Casino Open",
	casino_open_msg = "You can only use one casino at a time!",

	// Kiosk
	kiosk = "Kiosk",
	kiosk_limit = "You can only use one kiosk at a time!",
	kiosk_inuse = "This kiosk is in use by another player.",
	too_far = "You are too far away to do this!",
	kiosk_leave = "You have left the kiosk.",
	kiosk_save = "Kiosk Save",
	kiosk_save_message = "%i kiosks have been saved.",
	kiosk_only = "You can only use kiosks to access the casino",

	// Roulette
	roulette_chat_win = "You have won %i gems! (Red: %i, Black: %i, Green: %i)",
	roulette_chat_lose = "You have lost %i gems! (Red: %i, Black: %i, Green: %i)",

	// Crash
	you_have_won_x_at = "You have won %i gems @ %s",
	cashout_limit = "Cashout Limit",
	cashout_limit_message = "Enter the max multiplier you would like to auto cashout",
}
mCasino.addLanguage("en",lang)