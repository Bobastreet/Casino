--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}

function PANEL:Init()
	self.items = {}
end

function PANEL:AddItem(name,img,frm)
	local item = self:Add("mCasino_devKit_sidebarButton")
	item:SetText(name)
	item:SetImage(mCasino.GetPNG(img))
	item.DoClick = function()
		if(self.OnSwitchPanel)then
			self.OnSwitchPanel(frm)
		end
	end

	table.insert(self.items,item)
	self:InvalidateLayout()
end

function PANEL:Paint(w,h)
	draw.RoundedBox(0,0,0,w,h,mCasino.config.colors.sidebar)
end
function PANEL:PerformLayout(w,h)
	local yPos = 0
	for k,v in pairs(self.items) do
		v:SetSize(w,w)
		v:SetPos(0,yPos)
		v.yPos = yPos
		yPos = yPos + w
	end
end
vgui.Register( "mCasino_devKit_sidebar", PANEL, "DPanel" )