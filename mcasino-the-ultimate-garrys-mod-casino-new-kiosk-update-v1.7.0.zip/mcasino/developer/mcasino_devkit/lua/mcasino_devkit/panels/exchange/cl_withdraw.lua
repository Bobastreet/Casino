--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// The content base is just a DPanel with a scroll view and header title + help + mute toggle
// You can either create your own or just edit the paint function if you want to change colors
DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("withdraw"))
	self:SetHelpText(mCasino.getLang("withdraw_help"))
	// Withdraw List
	self.withdrawList = self.scroll:Add("DIconLayout")
	self:PopulateTypes()
	
	// Exchange updates occur when settings are change
    mCasino.setPanel(self, "exchange")
end

function PANEL:OnRemove()
    mCasino.setPanel(self, nil)
end

function PANEL:SendUpdate()
	self:PopulateTypes()
end

function PANEL:PopulateTypes()
	self.withdrawList:Clear()
	local types = mCasino.api.exchange.getTypes()
	for currencyId,data in pairs(types) do
		if(data.enabled())then
			self:AddWithdrawType(
				currencyId,
				data.withdrawRate() .. " = " .. data.format(1), 
				function() return data.format(data.get(LocalPlayer())) end,
				function()
					mCasino.api.exchange.promptWithdraw(currencyId,data)
				end
			)
		end
	end

	for k,v in pairs(mCasino.config.withdrawItems) do
		local item
		if(v.type == "weapon")then
			item = self.withdrawList:Add("mCasino_withdrawWeapon")
		end
		item:SetData(k)
	end
end

function PANEL:AddWithdrawType(currencyId, rate, balance, withdraw)
	local item = self.withdrawList:Add("mCasino_withdrawType")
	item:SetWithdrawType(currencyId)
	item:SetExchangeRate(rate)
	item:SetBalanceFunction(balance)
	item:SetWithdrawFunction(withdraw)
	self:InvalidateLayout()
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	self.withdrawList:SetSpaceY(self.ySpacing)
	
	local defaultH = h*0.85
	local panelH = h*0.35
	self.withdrawList:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.withdrawList:SetSize(w*self.pM,h*0.85)
	
	if(next(self.withdrawList:GetChildren())) then
		for k,v in pairs(self.withdrawList:GetChildren()) do
			v:SetSize(w,panelH)
		end
		self.withdrawList:SetTall((panelH+self.withdrawList:GetSpaceY())*#self.withdrawList:GetChildren())
		local newH = self.withdrawList:GetTall() + 150
		if(newH < defaultH) then newH = defaultH end
		self:SetTall(newH)
	else
		self:SetTall(defaultH)
	end
end
vgui.Register( "mCasino_devKit_withdraw", PANEL, "mCasino_contentBase" )