--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}

function PANEL:Init()
	// Create lobby button
	self.createLobby = self:Add("mCasino_button")
	self.createLobby:SetBGColor(mCasino.config.colors.accent)
	self.createLobby:SetHoverColor(Color(mCasino.config.colors.accent.r-5,mCasino.config.colors.accent.g-5,mCasino.config.colors.accent.b-5))
	
	// Session List
	self.sessionList = self:Add("mCasino_listView")
	self.sessionList.HideHeaders = true
	self.sessionList:SetSortable(false)
	self.sessionList:AddColumn(mCasino.getLang("session_name"))
	self.sessionList:AddColumn(mCasino.getLang("player_count"))
	self.sessionList:AddColumn("")
end

// Called after the lobby has been registered, self.gameData is available here
function PANEL:OnSetGame()
	self.createLobby:SetText(mCasino.getLang("create_x_session",mCasino.getLang(self.gameData.name)))
	self.createLobby.DoClick = function()
		mCasino.api.lobby.createSession(self.gameData.name)
	end
end

// This is called when the sessions list updates
function PANEL:PopulateSessionList(slData)
	self.sessionList:Clear()
	for k,v in pairs(slData) do
		self:AddSession(v.name,v.playerCount,v.owner)
	end
end

function PANEL:AddSession(name,curPlayers,sid)
	if not self.gameData then return end
	local playerCount = self.gameData.playersPerSession
	local btn = self:Add("mCasino_button")
	btn:SetText("Join")
	btn.DoClick = function()
		mCasino.api.lobby.joinSession(self.gameData.name,sid)
	end
	
	self.sessionList:AddLine(name,curPlayers .. "/" .. playerCount,btn)
end

function PANEL:Paint(w,h)
	draw.RoundedBox(0,0,0,w,h,mCasino.config.colors.bg)
end

function PANEL:PerformLayout(w,h)
	self.createLobby:SetSize(w,h*0.2)
	
	local tW = w*0.98
	local spacing = h*0.03
	self.sessionList:SetPos(w*0.5 - tW*0.5,h*0.2 + spacing)
	self.sessionList:SetSize(tW,h*0.8 - (spacing*2))
end

mCasino_devKit.onFinishLoad(function()
	// IMPORTANT: Inject lobby methods into panel
	mCasino.api.lobby.inject(PANEL)
	vgui.Register( "mCasino_devKit_lobby", PANEL, "DPanel" )
end)