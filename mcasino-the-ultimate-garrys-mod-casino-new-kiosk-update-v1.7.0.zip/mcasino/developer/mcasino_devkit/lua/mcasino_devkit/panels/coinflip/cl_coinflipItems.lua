--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}

function PANEL:Init()
    self.players = {}
    self.players[1] = self:Add("mCasino_coinflipItemList")
    self.players[2] = self:Add("mCasino_coinflipItemList")

end

function PANEL:SetData(data)
    mCasino.api.coinflip.handleUpdate(
        data,
        function(plyData, index)
            if(plyData.items)then
                self.players[index]:SetItems(plyData.items)
            end
        end
    )

    local p1Pecent, p2Percent = mCasino.api.coinflip.calculatePercentage(data)
    self.players[1]:SetPercentage(p1Pecent)
    self.players[2]:SetPercentage(p2Percent)
end

function PANEL:Paint(w,h)
end

function PANEL:PerformLayout(w,h)
    local pW = w*0.48
    self.players[1]:SetSize(pW,h)

    self.players[2]:SetSize(pW,h)
    self.players[2]:SetPos(w-pW)

end
vgui.Register( "mCasino_devKit_coinflipItems", PANEL, "DPanel" )
