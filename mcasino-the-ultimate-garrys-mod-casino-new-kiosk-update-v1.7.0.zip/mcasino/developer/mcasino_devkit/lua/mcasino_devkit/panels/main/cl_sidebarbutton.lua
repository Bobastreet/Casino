--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}
AccessorFunc(PANEL, "m_iImage", "Image")
AccessorFunc(PANEL, "m_iPos", "yPos")

function PANEL:Init()
	// Enable Button Support
	self:SetMouseInputEnabled(true)
	self:SetCursor( "hand" )
end

function PANEL:Paint(w,h)
	if(mCasino.config.paint["sidebarButton"]) then
		mCasino.config.paint["sidebarButton"](self, w, h)
		return
	end
	if(self.Hovered) then
		draw.RoundedBox(0,0,0,w,h, mCasino.config.colors.hover)
	else
		draw.RoundedBox(0,0,0,w,h, mCasino.config.colors.sidebar)
	end
	
	surface.SetDrawColor(color_white)
	surface.SetMaterial(self:GetImage())
	local iW, iH = w*0.7, h*0.7
	local iX, iY = w*0.5-iW*0.5, h*0.5-iH*0.5
	surface.DrawTexturedRect(iX,iY,iW,iH)
end

function PANEL:SetText(txt)
	self.txt = txt
end

function PANEL:OnMousePressed(enum)
	if(self.DoClick and (enum == MOUSE_LEFT or enum == IN_USE)) then
		self.DoClick(self)
	end
end

function PANEL:OnCursorEntered()
	self.Hovered = true
	if(!IsValid(self.info))then
		local sidebar = self:GetParent()
		local mainWindow = sidebar:GetParent()
		self.info = vgui.Create("mCasino_sidebarButtonInfo",mainWindow)
		local sX, sY = sidebar:GetPos()
		self.info:SetPos(sX + sidebar:GetWide(), sY + (self.yPos or 0))
		self.info:SetSize(mainWindow:GetWide()*0.15, self:GetTall())
		self.info:SetText(self.txt)
		self.info:MoveToFront()
	end
end
function PANEL:OnCursorExited()
	self.Hovered = false
	if(IsValid(self.info)) then
		self.info:Remove()
	end
end

vgui.Register( "mCasino_devKit_sidebarButton", PANEL, "DPanel" )

local PANEL = {}
AccessorFunc(PANEL, "m_sText", "Text")
function PANEL:Init()  end
function PANEL:Paint(w,h)
	draw.RoundedBox(0,0,0,w,h,mCasino.config.colors.hover)
	draw.SimpleText(self:GetText() or "", "mCasino_default", 4, h*0.5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
vgui.Register( "mCasino_devKit_sidebarButtonInfo", PANEL, "DPanel" )