--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

--[[
	This is the main frame for mCasino, you can abstract from it whatever you like!
	The main parts are:
	- Do not use mCasino if it isn't loaded (line 25)
	- This panel should be the root parent of all components that use mCasino 
	- Implement PANEL:GetOtherUser() and PANEL:IsOtherUser()
	- Add your panel name using mCasino.setRootPanel(frameName)
	- You should only have one instance of mCasino at a time
--]]

local PANEL = {}

function PANEL:AddSidebarItem(title,icon,frame)
	table.insert(self.sidebarItems,{title=title,icon=icon,frame=frame})
	self.sidebar:AddItem(title,icon,frame)
end

local frameName = "mCasino_devKit_frame"

function PANEL:Init()
	// IMPORTANT- Do not use mCasino if it is not loaded
	if not mCasino then return end
	if not IsValid(LocalPlayer()) then return end -- Valid player check

	// Add panel to rootPanels (this panel should implement GetOtherUser and IsOtherUser)
	mCasino.setRootPanel(frameName)

	// DFrame Settings
	self:SetDraggable(true)
	self:ShowCloseButton(false)
	self:SetTitle("")

	// Header
	self.header = self:Add("mCasino_mainHeader")
	self.header:SetClosePanel(self)
	self.header.OnSwitchPanel = function(panel)
		self:SwitchPanel(panel)
	end
	
	// Sidebar
	self.sidebar = self:Add("mCasino_devKit_sidebar")
	self.sidebar.OnSwitchPanel = function(panel)
		self:SwitchPanel(panel)
	end

	// Sidebar items
	self.sidebarItems = {}
	
	// Sidebar elements
	for _, v in pairs(mCasino.api.games.getGames()) do
		// For this dev kit, we check if there is a panel available before adding it to the menu
		local key = "mCasino_devKit_" .. v.key
		if(vgui.GetControlTable(key))then
			self:AddSidebarItem(v.name, v.icon, key, v.enabled)
		end
	end

	self:AddSidebarItem(mCasino.getLang("deposit"), mCasino.getIcon("gem","mcasino/gem.png"), "mCasino_devKit_deposit")
	self:AddSidebarItem(mCasino.getLang("withdraw"), mCasino.getIcon("cart","mcasino/cart.png"), "mCasino_devKit_withdraw")

	local ply = LocalPlayer()

	// These are admin tools
	if(mCasino.api.permissions.canEdit(ply))then
		self:AddSidebarItem(mCasino.getLang("settings"), mCasino.getIcon("settings","mcasino/settings.png"), "mCasino_settings")
	end
	if(mCasino.api.permissions.canManageGems(ply))then
		self:AddSidebarItem(mCasino.getLang("gem_management"), mCasino.getIcon("exchange","mcasino/exchange.png"), "mCasino_gemManagement")
	end

	// Main View
	for k,v in pairs(self.sidebarItems) do
		self:SwitchPanel(v.frame)
		break
	end
end

function PANEL:SwitchPanel(frm)
	if(frm == self.currentFrame) then return end
	if(IsValid(self.content))then
		self.content:Remove()
	end
	self.content = self:Add(frm)
	self:InvalidateLayout()
	self.currentFrame = frm
end

function PANEL:GetOtherUser()
	return LocalPlayer()
end

function PANEL:IsOtherUser()
	return false
end

function PANEL:Paint(w,h)
	draw.RoundedBox(0,0,0,w,h,mCasino.config.colors.bg)
end

function PANEL:PerformLayout(w,h)
	self.header:SetSize(w,h*0.08)
	
	self.sidebar:SetPos(0,h*0.08)
	self.sidebar:SetSize(h*0.08,h*0.92)
	
	if(IsValid(self.content))then
		self.content:SetPos(h*0.08,h*0.08)
		self.content:SetSize(w-h*0.08,h*0.92)
	end
end
vgui.Register( frameName, PANEL, "DFrame" )