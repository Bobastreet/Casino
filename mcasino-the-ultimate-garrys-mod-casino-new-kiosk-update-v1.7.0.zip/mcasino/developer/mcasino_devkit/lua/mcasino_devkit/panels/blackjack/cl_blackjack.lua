--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// The content base is just a DPanel with a scroll view and header title + help + mute toggle
// You can either create your own or just edit the paint function if you want to change colors
DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("blackjack"))
	self:SetHelpText(mCasino.getLang("blackjack_help"))
	
	// Back
	self.back = self.scroll:Add("mCasino_button")
	self.back:SetText("X")
	self.back.DoClick = function()
		self.lobby:Leave()
		self:SetupLobby()
	end

	// Popup
	self.popup = self.scroll:Add("mCasino_button")
	self.popup:SetText("S")
	self.popup.DoClick = function()
		if(mCasino.api.blackjack.isSummaryEnabled())then
			mCasino.api.blackjack.setSummaryEnabled(false)
		else
			mCasino.api.blackjack.setSummaryEnabled(true)
		end
	end
	self.popup:SetVisible(false)
	self.popup.OldPaint = self.popup.Paint
	self.popup.Paint = function(s,w,h)
		self.popup.OldPaint(s,w,h)
		if(!mCasino.api.blackjack.isSummaryEnabled())then
			surface.SetDrawColor(Color(255,0,0,255))
			surface.DrawLine(w*0.1, h*0.9, w*0.9, h*0.1)
		end
	end
	self.popup:SetTooltip(mCasino.getLang("summary"))

	self.lobby = self:Add("mCasino_devKit_lobby")
	self.lobby:SetGame("blackjack")
	self.lobby.OnClientJoin = function(session)
		self:SetupGame(session)
	end
	self.lobby.OnSessionUpdate = function(session)
		if not IsValid(self.gameView) then return end
		self.gameView:SetData(session)
	end
	
	mCasino.setPanel(self, "blackjack")
	self:SetupLobby()
end

function PANEL:OnRemove()
	mCasino.setPanel(self, nil)
end

function PANEL:SetupLobby()
	if(IsValid(self.gameView))then
		self.gameView:Remove()
	end
	self.back:SetVisible(false)
	self.lobby:SetVisible(true)
end

function PANEL:SetupGame(session)
	self.lobby:SetVisible(false)
	self.back:SetVisible(true)
	if(IsValid(self.gameView))then
		self.gameView:SetVisible(true)
	else
		self.gameView = self:Add("mCasino_blackjackGameView")
	end
	self.gameView:SetData(session)
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	
	if(IsValid(self.gameView))then
		self.gameView:SetPos(0,h*0.1)
		self.gameView:SetSize(w,h*0.9)
	end
	
	if(IsValid(self.lobby))then
		self.lobby:SetPos(0,h*0.1)
		self.lobby:SetSize(w,h*0.9)
	end
	
	self.back:SetSize(h*0.05,h*0.05)
	self.back:SetPos(select(1,self.help:GetPos()) - self.back:GetWide() - 4,h*0.025)

	if(self.back:IsVisible())then
		self.popup:SetVisible(true)
		self.popup:SetSize(h*0.05,h*0.05)
		self.popup:SetPos(select(1,self.back:GetPos()) - self.popup:GetWide() - 4,h*0.025)
	else
		self.popup:SetVisible(false)
	end
end
vgui.Register( "mCasino_devKit_blackjack", PANEL, "mCasino_contentBase" )
