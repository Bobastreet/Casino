--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// The content base is just a DPanel with a scroll view and header title + help + mute toggle
// You can either create your own or just edit the paint function if you want to change colors
DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("slots"))
	self:SetHelpText(mCasino.getLang("slots_help"))
	
	self.autoSpin = false

	// Mute
	self:AddMute()
	
	// Paytable
	self.paytable = self.scroll:Add("mCasino_button")
	self.paytable:SetText("$")
	self.paytable.DoClick = function()
		if(IsValid(self.paytablePanel)) then
			self.paytablePanel:Remove()
		end
        self.paytablePanel = mCasino.api.slots.paytable()
		self.paytablePanel = panel
	end
	
	// Wheels
	self.wheels = self.scroll:Add("mCasino_slotsWheels")
	
	// Bet
	self.bet = self.scroll:Add("mCasino_slotsBet")
	self.winView = self.scroll:Add("mCasino_winView")
	self.winView:SetText(mCasino.getLang("place_bet_start"))

    local isOtherUser = mCasino.getRootPanel(self):IsOtherUser()

	self.bet:SetVisible(not isOtherUser)
	self.winView:SetVisible(isOtherUser)
	
	// Spin Button
	self.spin = self.scroll:Add("mCasino_button")
	self.spin:SetText(mCasino.getLang("spin"))
	self.spin:SetOutline(true)
	self.spin.DoClick = function()
		self:Spin()
	end
	self.spin:SetVisible(not isOtherUser)

	// Auto Spin
	self.auto = self.scroll:Add("mCasino_button")
	self.auto:SetText(mCasino.getLang("auto_spin_x",mCasino.getLang("off")))
	self.auto:SetOutline(true)
	self.auto.DoClick = function()
		if(self.autoSpin)then
			self:SetAutoSpin(false)
		elseif(LocalPlayer():canAffordGems(self.bet:GetBet()))then
			self:SetAutoSpin(true)
		end
	end
	self.auto:SetVisible(not isOtherUser)
	
	self.wheels.onSpinComplete = function()
		mCasino.api.slots.handleSpinComplete(
			mCasino.getRootPlayer(self),
			self.bet:GetBet(),
			self.SpinData,
			self.autoSpin,
			function(shouldSpin)
				if(not IsValid(self)) then return end
				if(shouldSpin)then
					self:Spin()
				else
                	self:SetAutoSpin(false)
				end
			end,
			function(status)
				if(not IsValid(self)) then return end
				self.winView:SetText(status)
			end,
			function()
				if(IsValid(self) and IsValid(self:GetEntity())) then
					self:GetEntity():OnWin()
				end
			end
		)
	end

	// Register panel for updates
    mCasino.setPanel(self, "slots")
end

function PANEL:OnRemove()
	// Unregister panel
    mCasino.setPanel(self, nil)
end

function PANEL:SetAutoSpin(bool)
	if(bool)then
		self.spin:SetDisabled(true)
		self.autoSpin = true
		self.auto:SetText(mCasino.getLang("auto_spin_x",mCasino.getLang("on")))
		self:Spin()
	else
		self.autoSpin = false
		self.auto:SetText(mCasino.getLang("auto_spin_x",mCasino.getLang("off")))
		self.spin:SetDisabled(false)
	end
end

function PANEL:Spin()
	mCasino.api.slots.bet(self.bet:GetBet())
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:SendUpdate()
	local ply = mCasino.getRootPlayer(self)

	mCasino.api.slots.handleUpdate(
		ply,
		self.LastSpinTime,
		function(data)
			self.LastSpinTime = data.startTime
			self.SpinData = data
			self.wheels:Spin(data.symbols)
		end,
		function(status)
			self.winView:SetText(status)
		end
	)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	
	self.mute:SetSize(h*0.05,h*0.05)
	self.mute:SetPos(select(1,self.help:GetPos()) - self.mute:GetWide() - 4,h*0.025)
	
	self.paytable:SetSize(h*0.05,h*0.05)
	self.paytable:SetPos(select(1,self.mute:GetPos()) - self.paytable:GetWide() - 4,h*0.025)
	
	self.yPos = self.yPos + self.ySpacing
	self.wheels:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.wheels:SetSize(w*self.pM,h*0.5)
	self.yPos = self.yPos + h*0.5
	
	self.yPos = self.yPos + self.ySpacing
	self.bet:SetPos(w*0.5 - w*self.pM*0.5, self.yPos)
	self.bet:SetSize(w*self.pM,h*0.1)

	if(IsValid(self.winView))then
		self.winView:SetPos(w*0.5 - w*self.pM*0.5, self.yPos)
		self.winView:SetSize(w*self.pM,h*0.1)
	end

	self.yPos = self.yPos + h*0.1
	
	self.yPos = self.yPos + self.ySpacing
	self.spin:SetPos(w*0.5 - w*self.pM*0.5, self.yPos)
	self.spin:SetSize(w*0.8*self.pM,h*0.1)

	self.auto:SetPos(w*0.5 - w*self.pM*0.5 + w*0.8, self.yPos)
	self.auto:SetSize(w*0.183*self.pM,h*0.1)

	self.yPos = self.yPos + h*0.1
end
vgui.Register( "mCasino_devKit_slots", PANEL, "mCasino_contentBase" )
