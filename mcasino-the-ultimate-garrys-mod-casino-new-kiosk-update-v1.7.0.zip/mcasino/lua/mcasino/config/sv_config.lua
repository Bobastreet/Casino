--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4d.one/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2021 M4D.one All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D.one is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// FILE VERSION: 1 - View lastest versions here: https://docs.m4dsolutions.com/#/category/1/article/4
mCasino.config.fileVersions = mCasino.config.fileVersions or {}
mCasino.config.fileVersions["config/sv_config.lua"] = 1

// Documentation: https://docs.m4dsolutions.com/#/category/1/article/2

resource.AddWorkshop("1284756110") // mCasino Content

// Crash Testing Commands
// You can use these commands through the SERVER CONSOLE to see a test of outcomes
// mCasino_testCrashOutcomes - prints out the outcomes for the crash
// mCasino_testCrashHighOutcomes - prints out the outcomes if the crash is selected for a high outcome

// Crash Odds - Advanced
// This allows you to define a custom function that allows you to choose the crash point, it must return a number! 
// The in-game settings will not work when this function is enabled!
// ONLY UNCOMMENT THE FOLLOWING LINE IF YOU KNOW WHAT YOU ARE DOING! We may not offer support for your custom probability function!
//mCasino.config.crashCalculateCrash = function() return math.random(0,50) end

// Roulette Odds - Advanced
// This allows you to define a custom function that allows you to choose the outcome of the spin, it must return a number from 1-3
// 1=Red, 2=Black, 3=Green
// ONLY UNCOMMENT THE FOLLOWING LINE IF YOU KNOW WHAT YOU ARE DOING! We may not offer support for your custom probability function!
//mCasino.config.rouletteWinningColor = function() return math.random(1,3) end

// Storage
// When changing to MySQL, please read the following guide to ensure you have installed the libraries correctly.
// https://docs.m4dsolutions.com/#/category/1/article/5
mCasino.config.provider = "flatfile" // Storage Type, can be either "flatfile" or "mysql"

// ---- THESE SETTINGS ARE USED IF YOU ARE USING MYSQL ABOVE ---- //
mCasino.config.mysqlHost = "localhost" // MySQL Host
mCasino.config.mysqlUsername = "testuser" // MySQL Username
mCasino.config.mysqlPassword = "testpassword" // MySQL Password
mCasino.config.mysqlDatabase = "mcasino" // MySQL Database
mCasino.config.mysqlPort = 3306 // MySQL Port

//-----------------------------------------
if not mCasino.config then
	mCasino.Print(mCasino.getLang("invalid_config"))
	return
end

mCasino.Print(mCasino.getLang("loaded_config"))
hook.Call("mCasino_ConfigLoaded")