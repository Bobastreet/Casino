--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]


DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("jackpot"))
	self:SetHelpText(mCasino.getLang("jackpot_help"))

	self.chart = self.scroll:Add("mCasino_jackpotChart")

	// Bet Panel
	self.bet = self.scroll:Add("mCasino_jackpotBet")
	self.winView = self.scroll:Add("mCasino_winView")
	self.winView:SetText(mCasino.getLang("place_bet_start"))
	
    local isOtherUser = mCasino.getRootPanel(self):IsOtherUser()

	self.bet:SetVisible(not isOtherUser)
	self.winView:SetVisible(isOtherUser)
	
	// Scoreboard Panel
	self.scoreboard = self.scroll:Add("mCasino_jackpotScoreboard")

	if(isOtherUser)then
		self.bet:SetVisible(false)
	end

    mCasino.setPanel(self, "jackpot")
end

function PANEL:OnRemove()
    mCasino.setPanel(self, nil)
end

function PANEL:SendUpdate()
	
	self.scoreboard:Clear()

	// This generates self.players
	mCasino.api.jackpot.handleUpdate(
		self,
		function(plyData, chance)
			self.scoreboard:AddPlayer(plyData.ply,math.Round(chance*100, 2) .. "%", plyData.amount, plyData.col, plyData.winner)
		end,
		nil,
		function(status)
			self.winView:SetText(status)
		end,
		function()
			if(IsValid(self:GetEntity())) then
				self:GetEntity():OnWin()
			end
		end
	)

	self.scoreboard:DoSorting()
	self.chart:SetPlayers(mCasino.api.jackpot.getPlayers(), self.players)
	self:InvalidateLayout()
	self.bet:UpdateButton()
end

function PANEL:GetBet()
	return self.bet:GetBet()
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	
	self.yPos = self.yPos + self.ySpacing
	self.chart:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.chart:SetSize(w*0.48,h*0.4)
	self.chart:UpdateChart()

	self.bet:SetPos(w - w*self.pM*0.5,self.yPos)
	self.bet:SetSize(w*0.48,h*0.4)
	if(IsValid(self.winView))then
		self.winView:SetPos(w - w*self.pM*0.5,self.yPos)
		self.winView:SetSize(w*0.48,h*0.4)
	end
	self.yPos = self.yPos + h*0.4
	
	self.yPos = self.yPos + self.ySpacing
	self.scoreboard:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.scoreboard:SetSize(w*self.pM,h*0.4)
	
	local newH = #self.scoreboard.Lines * self.scoreboard:GetDataHeight() + self.scoreboard:GetHeaderHeight()
	if(newH < h*0.4)then
		self.scoreboard:SetTall(h*0.4)
	else
		self.scoreboard:SetTall(newH) 
	end
end
vgui.Register( "mCasino_devKit_jackpot", PANEL, "mCasino_contentBase" )