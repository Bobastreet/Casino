--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

// The content base is just a DPanel with a scroll view and header title + help + mute toggle
// You can either create your own or just edit the paint function if you want to change colors
DEFINE_BASECLASS("mCasino_contentBase")

local PANEL = {}

function PANEL:Init()
	self:SetTitle(mCasino.getLang("crash"))
	self:SetHelpText(mCasino.getLang("crash_help"))
	
	// History
	self.history = self.scroll:Add("mCasino_button")
	self.history:SetIcon("mcasino/history.png")
	self.history.DoClick = function()
		mCasino.history.openHistory("crash")
	end
	
	// Graph
	self.graph = self.scroll:Add("mCasino_crashGraph")
	
	// Bet Panel
	self.bet = self.scroll:Add("mCasino_crashBet")
	self.winView = self.scroll:Add("mCasino_winView")
	self.winView:SetText(mCasino.getLang("place_bet_start"))
	
	local isOtherUser = mCasino.getRootPanel(self):IsOtherUser()

	self.bet:SetVisible(not isOtherUser)
	self.winView:SetVisible(isOtherUser)
	self.winView:SetText(mCasino.getLang("place_bet_start"))
	self.winView.paintOverride = function(self,w,h)
		local state = mCasino.api.crash.getState()
		local states = mCasino.api.crash.getStates()
		if(self.playerData and state == states["RISING"] and not self.playerData.cashedOut)then
			draw.SimpleText(mCasino.getLang("cashout_at_x", math.Round(self.playerData.amount *(mCasino.api.crash.getCurrentValue() or 1))), "mCasino_default", w*0.5, h*0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return true
		end
	end

	// Scoreboard Panel
	self.scoreboard = self.scroll:Add("mCasino_crashScoreboard")
	
	if(isOtherUser)then
		self.bet:SetVisible(false)
	end

    mCasino.setPanel(self, "crash")
end

function PANEL:OnRemove()
    mCasino.setPanel(self, nil)
end

function PANEL:SendUpdate()
	self.scoreboard:Clear()

    mCasino.api.crash.handleUpdate(
        self, 
        function(plyData)
            self.scoreboard:AddPlayer(plyData.ply,plyData.cashoutFinal,plyData.amount,plyData.profit,plyData.cashedOut,plyData.lost)
        end,
        function(plyData)
            self.winView.playerData = plyData
        end,
        function(status)
            self.winView:SetText(status)
        end,
        function()
            // If an entity is related, pass on the win
            if(IsValid(self:GetEntity()))then
                self:GetEntity():OnWin()
            end
        end
    )

	self.scoreboard:DoSorting()
	self:InvalidateLayout()
	self.bet:UpdateButton()

    if(mCasino.api.crash.shouldStart(self.lastUpdate))then
		self.graph:StartCrash()
	end
	
	if(mCasino.api.crash.shouldFinish(self.lastUpdate))then
		self.graph:FinishCrash()
	end

	self.lastUpdate = mCasino.api.crash.getState()
end

function PANEL:Paint(w,h)
	BaseClass.Paint(self,w,h)
end

function PANEL:PerformLayout(w,h)
	BaseClass.PerformLayout(self,w,h)
	
	self.history:SetSize(h*0.05,h*0.05)
	self.history:SetPos(select(1,self.help:GetPos()) - self.history:GetWide() - 4,h*0.025)
	
	self.yPos = self.yPos + self.ySpacing
	self.graph:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.graph:SetSize(w*0.48,h*0.4)
	
	self.bet:SetPos(w - w*self.pM*0.5,self.yPos)
	self.bet:SetSize(w*0.48,h*0.4)
	if(IsValid(self.winView))then
		self.winView:SetPos(w - w*self.pM*0.5,self.yPos)
		self.winView:SetSize(w*0.48,h*0.4)
	end
	self.yPos = self.yPos + h*0.4
	
	self.yPos = self.yPos + self.ySpacing
	self.scoreboard:SetPos(w*0.5 - w*self.pM*0.5,self.yPos)
	self.scoreboard:SetSize(w*self.pM,h*0.4)
	
	local newH = #self.scoreboard.Lines * self.scoreboard:GetDataHeight() + self.scoreboard:GetHeaderHeight()
	if(newH < h*0.4)then
		self.scoreboard:SetTall(h*0.4)
	else
		self.scoreboard:SetTall(newH) 
	end
end
vgui.Register( "mCasino_devKit_crash", PANEL, "mCasino_contentBase" )