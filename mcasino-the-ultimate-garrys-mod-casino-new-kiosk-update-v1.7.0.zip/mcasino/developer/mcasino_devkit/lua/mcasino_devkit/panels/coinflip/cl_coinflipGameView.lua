--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}

function PANEL:Init()
	self.players = self:Add("mCasino_devKit_coinflipPlayers")
	self.mainItems = self:Add("mCasino_devKit_coinflipItems")
end

function PANEL:SetData(session)
	self.data = session
	self.players:SetData(session.gameData)
	self.mainItems:SetData(session.gameData)
end

function PANEL:GetData()
	return self.data
end

function PANEL:Paint(w,h)

end

function PANEL:PerformLayout(w,h)
	local pW, pH = w * 0.98, h * 0.35
	self.players:SetSize(pW, pH)
	self.players:SetPos(w * 0.5 - pW * 0.5, h * 0.02)

	self.mainItems:SetPos(w * 0.5 - pW * 0.5, pH + h * 0.04)
	self.mainItems:SetSize(pW, h-pH-h * 0.08)
end
vgui.Register( "mCasino_devKit_coinflipGameView", PANEL, "DPanel" )
