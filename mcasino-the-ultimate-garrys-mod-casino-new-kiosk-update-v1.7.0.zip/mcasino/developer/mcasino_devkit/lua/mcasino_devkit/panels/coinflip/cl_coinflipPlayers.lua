--[[
	mCasino (M4D Casino)
	Created by M4D | http://m4dsolutions.com/ | http://steamcommunity.com/id/m4dhead |
	Copyright © 2022 M4D Solutions All Rights Reserved
	All 3rd party content is public domain or used with permission
	M4D Solutions is the copyright holder of all code below. Do not distribute in any circumstances.
--]]

local PANEL = {}

function PANEL:Init()
    self.players = {}
    self.players[1] = self:Add("mCasino_coinflipPlayerCard")
    self.players[2] = self:Add("mCasino_coinflipPlayerCard")

    self.coin = self:Add("mCasino_coinflipCoin")
end

function PANEL:SetData(data)

    mCasino.api.coinflip.handleUpdate(
        data,
        function(plyData, index)
            self.players[index]:SetData(data)
            self.players[index]:SetPosition(index)
            if not IsValid(plyData.ply) then return end
            self.players[index]:SetPlayer(plyData.ply)
            self.players[index]:SetJoinable(false)
        end,
        function()
            self.coin:SetCountdown(data.nextState)
        end,
        function()
            if(not self.coin:IsSpinning())then
                self.coin:FlipCoin(data.flip)
            end
        end,
        function(flip)
            self.coin:SetSide(flip)
            if (flip) then
                self.players[1]:SetWin(true, data.endTime)
            else
                self.players[2]:SetWin(true, data.endTime)
            end
            local ent = mCasino.getRootEntity(self)
            if(IsValid(ent) and ent:GetPlayer() == data.positions[data.flip and 1 or 2].ply) then
                ent:OnWin()
            end
        end
    )
end

function PANEL:Paint(w,h)
end

function PANEL:PerformLayout(w,h)
    local pW = w * 0.35
    self.players[1]:SetSize(pW,h)

    self.players[2]:SetSize(pW,h)
    self.players[2]:SetPos(w-pW)

    self.coin:SetPos(pW + 8)
    self.coin:SetSize(w-(pW * 2) - 16, h)
end
vgui.Register( "mCasino_devKit_coinflipPlayers", PANEL, "DPanel" )
